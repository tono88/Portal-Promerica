<?php

class __Mustache_0760527301b55a7d565f2555a4ca7b65 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<li class="m-t-1">
';
        $buffer .= $indent . '    <div class="bg-pulse-grey" style="height: 25px; width: 50%;"></div>
';
        $buffer .= $indent . '    <div class="m-t-1">
';
        $buffer .= $indent . '        <ul class="media-list">
';
        if ($partial = $this->mustache->loadPartial('block_timeline/placeholder-event-list-item')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        if ($partial = $this->mustache->loadPartial('block_timeline/placeholder-event-list-item')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        if ($partial = $this->mustache->loadPartial('block_timeline/placeholder-event-list-item')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        if ($partial = $this->mustache->loadPartial('block_timeline/placeholder-event-list-item')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        if ($partial = $this->mustache->loadPartial('block_timeline/placeholder-event-list-item')) {
            $buffer .= $partial->renderInternal($context, $indent . '            ');
        }
        $buffer .= $indent . '        </ul>
';
        $buffer .= $indent . '        <div class="m-t-1">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey pull-right" style="height: 35px; width: 25%;"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey" style="height: 35px; width: 25%;"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</li>
';

        return $buffer;
    }
}
