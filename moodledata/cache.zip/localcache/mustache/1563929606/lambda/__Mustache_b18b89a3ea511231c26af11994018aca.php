<?php

class __Mustache_b18b89a3ea511231c26af11994018aca extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<li class="media" style="height: 32px">
';
        $buffer .= $indent . '    <div class="bg-pulse-grey pull-left" style="height: 32px; width: 32px; border-radius: 50%"></div>
';
        $buffer .= $indent . '    <div class="media-body">
';
        $buffer .= $indent . '        <div class="bg-pulse-grey" style="height: 15px;"></div>
';
        $buffer .= $indent . '        <div class="bg-pulse-grey" style="height: 10px; margin-top: 7px; width: 75%"></div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</li>
';

        return $buffer;
    }
}
